/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_mp;

/**
 *
 * @author KAN~FUSED
 */
public class Order {
    
    public static void send() {
    	 
         //from,password,to,subject,message  
         Sender.send("ksrjena@gmail.com","erotlradqhqiprro"
         		+ "",Create_acc.uname.getText(),"Theemium OTP","Order details-"+Refreshments.i1.getText()+" "+Refreshments.i2.getText()+" "+Refreshments.i3.getText()+" "+Refreshments.i4.getText()+" "+Refreshments.i5.getText()+" "+Refreshments.i6.getText()+" "+Refreshments.i7.getText()+" "+Refreshments.i8.getText()+" "+Refreshments.i9.getText()+" "+Refreshments.i10.getText()+" "+Refreshments.i11.getText()+" "+Refreshments.i12.getText()+"\n Total = "+Refreshments.sum+"Rs"+"\nThank You!"); 
          
         Sender.send("ksrjena@gmail.com","erotlradqhqiprro"
         		+ "",JAVA_MP.uname.getText(),"Theemium OTP","Order details-"+Refreshments.i1.getText()+" "+Refreshments.i2.getText()+" "+Refreshments.i3.getText()+" "+Refreshments.i4.getText()+" "+Refreshments.i5.getText()+" "+Refreshments.i6.getText()+" "+Refreshments.i7.getText()+" "+Refreshments.i8.getText()+" "+Refreshments.i9.getText()+" "+Refreshments.i10.getText()+" "+Refreshments.i11.getText()+" "+Refreshments.i12.getText()+"\n Total = "+Refreshments.sum+"\nThank You!"); 
         
     }    
}
