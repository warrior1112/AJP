/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_mp;

import java.util.Random;

/**
 *
 * @author KAN~FUSED
 */
public class GENERATOR {
    public static char[] generatorOTP(int length) 
      { 

                  //Creating object of Random class
        Random obj = new Random(); 
        char[] otp = new char[length]; 
        for (int i=0; i<length; i++) 
        { 
          otp[i]= (char)(obj.nextInt(10)+48); 
        } 
        return otp; 
      } 
}
