/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_mp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;



public class Lunch implements MouseListener {
    JFrame f = new JFrame();
     JButton close;
    JMenuBar mb;    
JMenu name,about,home,refreshments,dinner,breakfast,lunch;    
JMenuItem cut,copy,paste,selectAll;    
JTextArea ta;
JPanel b,r,l,d;
JLabel i1,i2,i3,i4;
    Lunch(){
        
         f.setUndecorated(true);
        f.setVisible(true);
         f.setLayout(null);
         f.setExtendedState(JFrame.MAXIMIZED_BOTH); 
         close = new JButton("X");
         close.setBounds(1865,0,50,50); 
         
         
         JLabel background=new JLabel(new ImageIcon 
        ("home.png")); // background image
         f.setContentPane(background);
         
        
//cut=new JMenuItem("cut");    
//copy=new JMenuItem("copy");    
//paste=new JMenuItem("paste");    
//selectAll=new JMenuItem("selectAll");       
mb=new JMenuBar();    


JMenu inv1 = new JMenu("                                                                              ");


name=new JMenu("THEEMIUM FOODS LUNCH");   
name.setBorder(null);
name.setForeground(new java.awt.Color(255, 153, 102));
name.setFont(new java.awt.Font("Forte", Font.ITALIC, 37));

mb.setBackground(new Color(0,0,0,185));


refreshments = new JMenu("Refreshments               ");
lunch = new JMenu("Lunch                             ");
dinner = new JMenu("Dinner                           ");
breakfast = new JMenu("Breakfast                     ");
home=new JMenu("Home                       ");    
about=new JMenu("About                     "); 

refreshments.addMouseListener(this);
lunch.addMouseListener(this);
dinner.addMouseListener(this);
breakfast.addMouseListener(this);
home.addMouseListener(this);
about.addMouseListener(this);

refreshments.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
lunch.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
dinner.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
breakfast.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
home.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
about.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));

refreshments.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
lunch.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
dinner.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
home.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
about.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
breakfast.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

refreshments.setForeground(Color.cyan);
home.setForeground(Color.cyan);
about.setForeground(Color.cyan);
lunch.setForeground(Color.cyan);
dinner.setForeground(Color.cyan);
breakfast.setForeground(Color.cyan);

 b = new JPanel();
 r = new JPanel();
 l = new JPanel();
 d = new JPanel();

b.setBounds(381,600,260,260);
b.setBackground(new Color(0,0,0,100));
i1=new JLabel(new ImageIcon("item1.png"));
b.add(i1);

r.setBounds(681,600,260,260);
r.setBackground(new Color(0,0,0,100));
i2=new JLabel(new ImageIcon("item2.png"));
r.add(i2);

l.setBounds(981,600,260,260);
l.setBackground(new Color(0,0,0,100));
i3=new JLabel(new ImageIcon("item3.png"));
l.add(i3);

d.setBounds(1281,600,260,260);
d.setBackground(new Color(0,0,0,100));
i4=new JLabel(new ImageIcon("item4.png"));
d.add(i4);

b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
d.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

b.addMouseListener(this);
r.addMouseListener(this);
l.addMouseListener(this);
d.addMouseListener(this);

 //add(background);
mb.add(name);
mb.add(inv1);
mb.add(home);
mb.add(about); 
mb.add(refreshments);
mb.add(breakfast);
mb.add(lunch);
mb.add(dinner);
f.setJMenuBar(mb);
f.add(b);
f.add(r);
f.add(l);
f.add(d);
     
 
          
         
         close.addActionListener(new ActionListener(){
               public void actionPerformed(ActionEvent e){
                   f.dispose();
               }
           });
         f.add(close);  
         
          f.add(mb);
         
    }
    public void mouseEntered(MouseEvent e) {
        if(e.getSource()==b){
        i1.setIcon(null);
        b.setBackground(Color.black);
        i1.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i1.setForeground(Color.cyan);
        i1.setText("Refreshments");
        
        }
         else if(e.getSource()==r){
        i2.setIcon(null);
        r.setBackground(Color.black);
        i2.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i2.setForeground(Color.cyan);
        i2.setText("Breakfast");
        }
          else if(e.getSource()==l){
        i3.setIcon(null);
        l.setBackground(Color.black);
        i3.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i3.setForeground(Color.cyan);
        i3.setText("Lunch");
        }
          else if(e.getSource()==d){
        i4.setIcon(null);
        d.setBackground(Color.black);
        i4.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i4.setForeground(Color.cyan);
        i4.setText("Dinner");
        }
    }
    
    public void mouseExited(MouseEvent e) {
     if(e.getSource()==b){
            i1.setIcon(new ImageIcon("item1.png"));
        b.setBackground(Color.DARK_GRAY);
        i1.setText(" ");
        i1.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        
        }
     else if(e.getSource()==r){
            i2.setIcon(new ImageIcon("item2.png"));
        r.setBackground(Color.DARK_GRAY);
        i2.setText(" ");
        i2.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        
        }
     else if(e.getSource()==l){
            i3.setIcon(new ImageIcon("item3.png"));
        l.setBackground(Color.DARK_GRAY);
        i3.setText(" ");
        i3.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        
        }
     else if(e.getSource()==d){
            i4.setIcon(new ImageIcon("item4.png"));
        d.setBackground(Color.DARK_GRAY);
        i4.setText(" ");
        i4.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        
        }
    
    }  
 
    
    public void mouseClicked(MouseEvent e) {
     if(e.getSource()==refreshments||e.getSource()==b ){
         f.dispose();
        new Refreshments();
        }
     else if(e.getSource()==breakfast || e.getSource()==r){
         f.dispose();
        new Breakfast();
        }
     else if(e.getSource()==lunch||e.getSource()==l){
        f.dispose();
        new Lunch();
        }
     else if(e.getSource()==dinner||e.getSource()==d){
       f.dispose();
       new Dinner();
        }
     else if(e.getSource()==home){
       f.dispose();
        new Home();
        }
     else if(e.getSource()==about){
  
        
        }
    
    }  
    public void mousePressed(MouseEvent e) {}  
    public void mouseReleased(MouseEvent e) {} 
        
    }

