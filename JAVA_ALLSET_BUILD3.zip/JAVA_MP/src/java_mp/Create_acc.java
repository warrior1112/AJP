/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_mp;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;
import javax.swing.*;

public class Create_acc {
    JFrame f = new JFrame();
     ResultSet rs;
      JLabel box ;
    String getOTP;
      JProgressBar jb;    
      int i=0,num=0;
      String path = "login_pass.accdb";
      String url = "jdbc:ucanaccess://"+path;
      Connection con= DriverManager.getConnection(url);
      Statement st = con.createStatement();
     static JTextField uname,otp;
      JPasswordField pass;
      JButton login,close,verify;
      
  
      Create_acc() throws SQLException, MessagingException{
        f.setUndecorated(true);
       JPanel p1 = new JPanel(); // login form border box 
       JPanel p2 = new JPanel(); // login logo
       p1.setBounds(670,200,580,590);
       p1.setBackground(new Color(0,0,0,175));
       p2.setBackground(new Color(0,0,0,0));
       p2.add(new JLabel(new ImageIcon("LOGO-removebg-preview.png")));
       p2.setBounds(854,100,200,200);
       
        JLabel background=new JLabel(new ImageIcon 
        ("CREATE_ACC_BG2.jpg")); // background image
        f.add(background);
       
    	f.setVisible(true);
        
        background.add(p2);
        
        box=new JLabel();
        box.setBounds(670,200,580,590);
        javax.swing.border.Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
        javax.swing.border.Border border2 = BorderFactory.createLineBorder(Color.GRAY, 15);
        
    
        box.setBorder(border1);
        background.setBorder(border2);
        
        
           jb=new JProgressBar(0,100);    
                  jb.setBounds(140,900,1600,40);            
                  jb.setStringPainted(true);   
                  jb.setValue(0);      
                  jb.setVisible(false);
                  background.add(jb);  
    	
        
        login = new JButton("sign up");
    	uname = new JTextField();
    	pass = new JPasswordField();
        close = new JButton("X");
        
        //otp { 
       
        otp = new JTextField();
        otp.setBounds(710,720,250,40);
        
        verify = new JButton("Verify");
        verify.setBounds(999,720,150,40);
        
        // }
        f.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        
                                   
    	uname.setBounds(710,300,500,50);
    	pass.setBounds(710,445,500,50);
        login.setBounds(830,600,250,60);
        close.setBounds(1865,0,50,50);
        box.add(pass);
         box.add(close);
        box.add(login);
        box.add(otp);
        box.add(verify);
        
           background.add(uname);
           background.add(box);
    background.add(pass);
    background.add(login); 
    background.add(close);
   background.add(otp);
   background.add(verify);
     background.add(p1);
       
        
         login.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               char p[] = new char[100];
               p = pass.getPassword();         
               String s = new String(p);
               System.out.println(s);
               
                try {
                    st.executeUpdate("insert into data(uname,pass) values('"+uname.getText()+"','"+s+"')");
                    getOTP = Mailer.send();
                    JOptionPane.showMessageDialog(f,"otp sent to your email address. Don't share this OTP with anyone else.");
                } catch (SQLException ex) {
                    System.out.print("error while updation"+st.toString());
                }
            } });
         
            verify.addActionListener(new ActionListener(){
               public void actionPerformed(ActionEvent e){
                   if(otp.getText().equals(getOTP)){
                        JOptionPane.showMessageDialog(f,"Account Verified. \n Back to sign-in");
                        f.dispose();
                       try {
                           new JAVA_MP();
                       } catch (SQLException ex) {
                          JOptionPane.showMessageDialog(f,"verification error !");
                       }
                        
                   }
               }
           });
         
        
         
          close.addActionListener(new ActionListener(){
               public void actionPerformed(ActionEvent e){
                   f.dispose();
               }
           });
        
         background.add(uname);
    background.add(pass);
    background.add(close); 
    background.add(box);           
        }  
      
              
    }

