/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_mp;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.*;

public class Create_acc extends JFrame{
     ResultSet rs;
      JLabel box ;
    
      JProgressBar jb;    
      int i=0,num=0;
      String path = "login_pass.accdb";
      String url = "jdbc:ucanaccess://"+path;
      Connection con= DriverManager.getConnection(url);
      Statement st = con.createStatement();
      JTextField uname;
      JPasswordField pass;
      JButton login,close;
      JLabel signup;
  
      Create_acc() throws SQLException{
        setUndecorated(true);
       JPanel p1 = new JPanel(); // login form border box 
       JPanel p2 = new JPanel(); // login logo
       p1.setBounds(670,200,580,590);
       p1.setBackground(new Color(0,0,0,175));
       p2.setBackground(new Color(0,0,0,0));
       p2.add(new JLabel(new ImageIcon("LOGO-removebg-preview.png")));
       p2.setBounds(854,100,200,200);
       
        JLabel background=new JLabel(new ImageIcon 
        ("CREATE_ACC_BG2.jpg")); // background image
        add(background);
       
    	setVisible(true);
        
        background.add(p2);
        
        box=new JLabel();
        box.setBounds(670,200,580,590);
        javax.swing.border.Border border1 = BorderFactory.createLineBorder(Color.WHITE, 10);
        javax.swing.border.Border border2 = BorderFactory.createLineBorder(Color.GRAY, 15);
        
    
        box.setBorder(border1);
        background.setBorder(border2);
        
        
           jb=new JProgressBar(0,100);    
                  jb.setBounds(140,900,1600,40);            
                  jb.setStringPainted(true);   
                  jb.setValue(0);      
                  jb.setVisible(false);
                  background.add(jb);  
    	
        
        login = new JButton("sign up");
    	uname = new JTextField();
    	pass = new JPasswordField();
        close = new JButton("X");
        signup = new JLabel("Don't have account?");
        
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        signup.setForeground(Color.BLUE.darker());
                                   
    	uname.setBounds(710,300,500,50);
    	pass.setBounds(710,445,500,50);
        login.setBounds(830,600,250,60);
        close.setBounds(1865,0,50,50);
        signup.setBounds(710,500,250,60);
        signup.setFont(new Font("serif",Font.PLAIN,18));
        signup.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        box.add(signup);
        box.add(pass);
         box.add(close);
        box.add(login);
         box.add(signup);
           background.add(uname);
           background.add(box);
    background.add(pass);
    background.add(login); 
    background.add(close);
    background.add(signup);
     background.add(p1);
       
        
         close.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               char p[] = new char[100];
               p = pass.getPassword();         
               String s = new String(p);
               System.out.println(s);
               
                try {
                    st.executeUpdate("insert into data(uname,pass) values('"+uname.getText()+"','"+s+"')");
                    System.out.println("signup sucess!");
                } catch (SQLException ex) {
                    System.out.print("error while updation"+st.toString());
                }
            } });
         
          close.addActionListener(new ActionListener(){
               public void actionPerformed(ActionEvent e){
                   dispose();
               }
           });
        
         background.add(uname);
    background.add(pass);
    background.add(close); 
    background.add(box);
   
              
    }
}
