
package java_mp;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.*;
import javax.swing.*;

public class Home extends JFrame {
       
    JButton close;
    JMenuBar mb;    
JMenu name,about,home,refreshments,dinner,breakfast,lunch;    
JMenuItem cut,copy,paste,selectAll;    
JTextArea ta;
    Home(){
        
         setUndecorated(true);
         setVisible(true);
         setLayout(null);
         setExtendedState(JFrame.MAXIMIZED_BOTH); 
         close = new JButton("X");
         close.setBounds(1865,0,50,50); 
         
         
         JLabel background=new JLabel(new ImageIcon 
        ("home.png")); // background image
         setContentPane(background);
         
        
//cut=new JMenuItem("cut");    
//copy=new JMenuItem("copy");    
//paste=new JMenuItem("paste");    
//selectAll=new JMenuItem("selectAll");       
mb=new JMenuBar();    


JMenu inv1 = new JMenu("                                                                              ");


name=new JMenu("THEEMIUM FOODS");   
name.setBorder(null);
name.setForeground(new java.awt.Color(255, 153, 102));
name.setFont(new java.awt.Font("Forte", Font.ITALIC, 32));

mb.setBackground(new Color(0,0,0,185));


refreshments = new JMenu("Refreshments                              ");
lunch = new JMenu("Lunch                                            ");
dinner = new JMenu("Dinner                                          ");
breakfast = new JMenu("Breakfast                                    ");
home=new JMenu("Home                           ");    
about=new JMenu("About                          "); 

refreshments.setFont(new java.awt.Font("Forte", Font.ITALIC, 18));
lunch.setFont(new java.awt.Font("Forte", Font.ITALIC, 18));
dinner.setFont(new java.awt.Font("Forte", Font.ITALIC, 18));
breakfast.setFont(new java.awt.Font("Forte", Font.ITALIC, 18));
home.setFont(new java.awt.Font("Forte", Font.ITALIC, 18));
about.setFont(new java.awt.Font("Forte", Font.ITALIC, 18));

refreshments.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
lunch.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
dinner.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
home.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
about.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
breakfast.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

refreshments.setForeground(Color.cyan);
home.setForeground(Color.cyan);
about.setForeground(Color.cyan);
lunch.setForeground(Color.cyan);
dinner.setForeground(Color.cyan);
breakfast.setForeground(Color.cyan);

 //add(background);
mb.add(name);
mb.add(inv1);
mb.add(home);
mb.add(about); 
mb.add(refreshments);
mb.add(breakfast);
mb.add(lunch);
mb.add(dinner);
setJMenuBar(mb);
     
 
          
         
         close.addActionListener(new ActionListener(){
               public void actionPerformed(ActionEvent e){
                   dispose();
               }
           });
         add(close);  
         
          add(mb);
         
    }
         
    
}
