/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_mp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author KAN~FUSED
 */
public class Refreshments implements MouseListener,ActionListener {
    JFrame f = new JFrame();
     JButton close;
    JMenuBar mb;    
JMenu name,about,home,refreshments,dinner,breakfast,lunch;    
JMenuItem cut,copy,paste,selectAll;    
JTextArea ta;
int pineapple=20,mango=15,apple=22,pepsi=25,fruitbeer=10,lemonsoda=13,coffee=18,greentea=30,cccoffee=40,sprite=26,cocacola=19,limca=23;
JPanel r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12;
JLabel i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12;
JButton r1b,r2b,r3b,r4b,r5b,r6b,r7b,r8b,r9b,r10b,r11b,r12b;
JButton r1c,r2c,r3c,r4c,r5c,r6c,r7c,r8c,r9c,r10c,r11c,r12c;
ArrayList<Integer> cart = new ArrayList<Integer>();
    Refreshments(){
       f.setUndecorated(true);
        f.setVisible(true);
         f.setLayout(null);
         f.setExtendedState(JFrame.MAXIMIZED_BOTH); 
         close = new JButton("X");
         close.setBounds(1865,0,50,50); 
         
         
         JLabel background=new JLabel(new ImageIcon 
        ("home.png")); // background image
         f.setContentPane(background);
         
        
//cut=new JMenuItem("cut");    
//copy=new JMenuItem("copy");    
//paste=new JMenuItem("paste");    
//selectAll=new JMenuItem("selectAll");       
mb=new JMenuBar();    


JMenu inv1 = new JMenu("                                                                              ");


name=new JMenu("THEEMIUM FOODS REFRESHMENTS");   
name.setBorder(null);
name.setForeground(new java.awt.Color(255, 153, 102));
name.setFont(new java.awt.Font("Forte", Font.ITALIC, 37));

mb.setBackground(new Color(0,0,0,185));


refreshments = new JMenu("Refreshments               ");
lunch = new JMenu("Lunch                  ");
dinner = new JMenu("Dinner                           ");
breakfast = new JMenu("Breakfast                     ");
home=new JMenu("Home                       ");    
about=new JMenu("About                     "); 

refreshments.addMouseListener(this);
lunch.addMouseListener(this);
dinner.addMouseListener(this);
breakfast.addMouseListener(this);
home.addMouseListener(this);
about.addMouseListener(this);

refreshments.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
lunch.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
dinner.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
breakfast.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
home.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
about.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));

refreshments.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
lunch.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
dinner.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
home.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
about.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
breakfast.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

refreshments.setForeground(Color.cyan);
home.setForeground(Color.cyan);
about.setForeground(Color.cyan);
lunch.setForeground(Color.cyan);
dinner.setForeground(Color.cyan);
breakfast.setForeground(Color.cyan);

 r1 = new JPanel();
 r2 = new JPanel();
 r3 = new JPanel();
 r4 = new JPanel();
 r5 = new JPanel();
 r6 = new JPanel();
 r7 = new JPanel();
 r8 = new JPanel();
 r9 = new JPanel();
 r10 = new JPanel();
 r11 = new JPanel();
 r12 = new JPanel();
 
    r1b = new JButton("buy now");
        r1c = new JButton("add to cart");
     r2b = new JButton("buy now");
        r2c = new JButton("add to cart");
   r3b = new JButton("buy now");
        r3c = new JButton("add to cart");
   r4b = new JButton("buy now");
        r4c = new JButton("add to cart");
    r5b = new JButton("buy now");
        r5c = new JButton("add to cart");
    r6b = new JButton("buy now");
        r6c = new JButton("add to cart");
    r7b = new JButton("buy now");
        r7c = new JButton("add to cart");
            r8b = new JButton("buy now");
        r8c = new JButton("add to cart");
     r9b = new JButton("buy now");
        r9c = new JButton("add to cart");
   r10b = new JButton("buy now");
        r10c = new JButton("add to cart");
     r11b = new JButton("buy now");
        r11c = new JButton("add to cart");
         r12b = new JButton("buy now");
        r12c = new JButton("add to cart");
        
        r1c.setBounds(390,340,130,50);
        r1b.setBounds(520,340,130,50);
        
        r2c.setBounds(680,340,130,50);
        r2b.setBounds(810,340,130,50);
        
        r3c.setBounds(981,340,130,50);
        r3b.setBounds(1111,340,130,50);
        
        r4c.setBounds(1280,340,130,50);
        r4b.setBounds(1410,340,130,50);
        
        r5c.setBounds(382,677,130,50);
        r5b.setBounds(512,677,130,50);
        
        r6c.setBounds(680,677,130,50);
        r6b.setBounds(810,677,130,50);
        
        r7c.setBounds(981,677,130,50);
        r7b.setBounds(1111,677,130,50);
        
        r8c.setBounds(1280,677,130,50);
        r8b.setBounds(1410,677,130,50);
               
        r9c.setBounds(382,975,130,50);
        r9b.setBounds(512,975,130,50);
        
        r10c.setBounds(680,975,130,50);
        r10b.setBounds(810,975,130,50);
        
        r11c.setBounds(981,975,130,50);
        r11b.setBounds(1111,975,130,50);
        
        r12c.setBounds(1280,975,130,50);
        r12b.setBounds(1410,975,130,50);
        
        
 

r1.setBounds(390,80,260,260);
r1.setBackground(new Color(0,0,0,100));
i1=new JLabel(new ImageIcon("r1.jpg"));
r1.add(i1);

r2.setBounds(681,80,260,260);
r2.setBackground(new Color(0,0,0,100));
i2=new JLabel(new ImageIcon("r2.jpg"));
r2.add(i2);

r3.setBounds(981,80,260,260);
r3.setBackground(new Color(0,0,0,100));
i3=new JLabel(new ImageIcon("r3.jpg"));
r3.add(i3);

r4.setBounds(1281,80,260,260);
r4.setBackground(new Color(0,0,0,100));
i4=new JLabel(new ImageIcon("r4.jpg"));
r4.add(i4);

r5.setBounds(381,415,260,260);
r5.setBackground(new Color(0,0,0,100));
i5=new JLabel(new ImageIcon("r5.jpg"));
r5.add(i5);

r6.setBounds(681,415,260,260);
r6.setBackground(new Color(0,0,0,100));
i6=new JLabel(new ImageIcon("r6.jpg"));
r6.add(i6);

r7.setBounds(981,415,260,260);
r7.setBackground(new Color(0,0,0,100));
i7=new JLabel(new ImageIcon("r7.jpg"));
r7.add(i7);

r8.setBounds(1281,415,260,260);
r8.setBackground(new Color(0,0,0,100));
i8=new JLabel(new ImageIcon("r8.jpg"));
r8.add(i8);

r9.setBounds(381,747,260,260);
r9.setBackground(new Color(0,0,0,100));
i9=new JLabel(new ImageIcon("r9.jpg"));
r9.add(i9);

r10.setBounds(681,747,260,260);
r10.setBackground(new Color(0,0,0,100));
i10=new JLabel(new ImageIcon("r10.png"));
r10.add(i10);

r11.setBounds(981,747,260,260);
r11.setBackground(new Color(0,0,0,100));
i11=new JLabel(new ImageIcon("r11.jpg"));
r11.add(i11);

r12.setBounds(1281,747,260,260);
r12.setBackground(new Color(0,0,0,100));
i12=new JLabel(new ImageIcon("r12.jpg"));
r12.add(i12);


r1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r3.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r4.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r5.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r6.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r7.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r8.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r9.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r10.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r11.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
r12.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

r1.addMouseListener(this);
r2.addMouseListener(this);
r3.addMouseListener(this);
r4.addMouseListener(this);
r5.addMouseListener(this);
r6.addMouseListener(this);
r7.addMouseListener(this);
r8.addMouseListener(this);
r9.addMouseListener(this);
r10.addMouseListener(this);
r11.addMouseListener(this);
r12.addMouseListener(this);

r1c.addActionListener(this);
r2c.addActionListener(this);
r3c.addActionListener(this);
r4c.addActionListener(this);
r5c.addActionListener(this);
r6c.addActionListener(this);
r7c.addActionListener(this);
r8c.addActionListener(this);
r9c.addActionListener(this);
r10c.addActionListener(this);
r11c.addActionListener(this);
r12c.addActionListener(this);

 //add(background);
mb.add(name);
mb.add(inv1);
mb.add(home);
mb.add(about); 
mb.add(refreshments);
mb.add(breakfast);
mb.add(lunch);
mb.add(dinner);
f.setJMenuBar(mb);
f.add(r1);
f.add(r2);
f.add(r3);
f.add(r4);
f.add(r5);
f.add(r6);
f.add(r7);
f.add(r8);
f.add(r9);
f.add(r10);
f.add(r11);
f.add(r12);

f.add(r1c); f.add(r7c);
f.add(r1b); f.add(r7b);
f.add(r2c); f.add(r8c);
f.add(r2b); f.add(r8b);
f.add(r3c); f.add(r9c);
f.add(r3b); f.add(r9b);
f.add(r4c); f.add(r10c);
f.add(r4b); f.add(r10b);
f.add(r5c); f.add(r11c);
f.add(r5b); f.add(r11b);
f.add(r6c); f.add(r12c);
f.add(r6b); f.add(r12b);
          
         
         close.addActionListener(new ActionListener(){
               public void actionPerformed(ActionEvent e){
                   f.dispose();
               }
           });
         f.add(close);  
         
          f.add(mb);
         
    }
    
    public void actionPerformed(ActionEvent e){
      if(e.getSource()==r1c){
          
         cart.add(pineapple);
         
        }
     else if(e.getSource()==r2c){
         
         cart.add(mango);
         
        }
     else if(e.getSource()==r3c){
         
    cart.add(apple);
         
        }
     else if(e.getSource()==r4c){
         
         cart.add(pepsi);
         
        }
      else if(e.getSource()==r5c){
         
          cart.add(fruitbeer);
        
        }
     else if(e.getSource()==r6c){
         cart.add(lemonsoda);
        
        }
     else if(e.getSource()==r7c){
        
        cart.add(coffee);
         
        }
      else if(e.getSource()==r8c){
       
          cart.add(greentea);
        
        }
     else if(e.getSource()==r9c){
         
        cart.add(cccoffee);
         
        }
     else if(e.getSource()==r10c){
    
         cart.add(sprite);
        
        }
     else if(e.getSource()==r11c){
           
        cart.add(cocacola);
         
        }
      else if(e.getSource()==r12c){
          
          cart.add(limca);
          
        }
    }
    
    public void mouseEntered(MouseEvent e) {
        if(e.getSource()==r1){
        i1.setIcon(null);
        r1.setBackground(Color.black);
        i1.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i1.setForeground(Color.cyan);
        i1.setText("20Rs");  
     

        }
        
         else if(e.getSource()==r2){
        i2.setIcon(null);
        r2.setBackground(Color.black);
        i2.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i2.setForeground(Color.cyan);
        i2.setText("15Rs");
    
      
        }
          else if(e.getSource()==r3){
        i3.setIcon(null);
        r3.setBackground(Color.black);
        i3.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i3.setForeground(Color.cyan);
        i3.setText("22Rs");
      
       
        }
          else if(e.getSource()==r4){
        i4.setIcon(null);
        r4.setBackground(Color.black);
        i4.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i4.setForeground(Color.cyan);
        i4.setText("25Rs");
      
       
        }
           else if(e.getSource()==r5){
        i5.setIcon(null);
        r5.setBackground(Color.black);
        i5.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i5.setForeground(Color.cyan);
        i5.setText("10Rs");
     
     
        }
           else if(e.getSource()==r6){
        i6.setIcon(null);
        r6.setBackground(Color.black);
        i6.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i6.setForeground(Color.cyan);
        i6.setText("13Rs");
     
        
        }
           else if(e.getSource()==r7){
        i7.setIcon(null);
        r7.setBackground(Color.black);
        i7.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i7.setForeground(Color.cyan);
        i7.setText("18Rs");
     
        }
           else if(e.getSource()==r8){
        i8.setIcon(null);
        r8.setBackground(Color.black);
        i8.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i8.setForeground(Color.cyan);
        i8.setText("30Rs");
    
        
        }
           else if(e.getSource()==r9){
        i9.setIcon(null);
        r9.setBackground(Color.black);
        i9.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i9.setForeground(Color.cyan);
        i9.setText("40Rs");
    
      
        }
           else if(e.getSource()==r10){
        i10.setIcon(null);
        r10.setBackground(Color.black);
        i10.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i10.setForeground(Color.cyan);
        i10.setText("26Rs");
      
      
        }
           else if(e.getSource()==r11){
        i11.setIcon(null);
        r11.setBackground(Color.black);
        i11.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i11.setForeground(Color.cyan);
        i11.setText("19Rs");
    
        }
           else if(e.getSource()==r12){
        i12.setIcon(null);
        r12.setBackground(Color.black);
        i12.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        i12.setForeground(Color.cyan);
        i12.setText("23Rs");
  
     
        }
        
    }
    
    public void mouseExited(MouseEvent e) {
     if(e.getSource()==r1){
            i1.setIcon(new ImageIcon("r1.jpg"));
        r1.setBackground(Color.DARK_GRAY);
        i1.setText(" ");
        i1.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
        r1.remove(r1b);
        r1.remove(r1c);
        
        }
     else if(e.getSource()==r2){
            i2.setIcon(new ImageIcon("r2.jpg"));
        r2.setBackground(Color.DARK_GRAY);
        i2.setText(" ");
        i2.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r2.remove(r2b);
        r2.remove(r2c);
        
        }
     else if(e.getSource()==r3){
            i3.setIcon(new ImageIcon("r3.jpg"));
        r3.setBackground(Color.DARK_GRAY);
        i3.setText(" ");
        i3.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r3.remove(r3b);
        r3.remove(r3c);
        
        }
     else if(e.getSource()==r4){
            i4.setIcon(new ImageIcon("r4.jpg"));
        r4.setBackground(Color.DARK_GRAY);
        i4.setText(" ");
        i4.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r4.remove(r4b);
        r4.remove(r4c);
        
        }
      else if(e.getSource()==r5){
            i5.setIcon(new ImageIcon("r5.jpg"));
        r5.setBackground(Color.DARK_GRAY);
        i5.setText(" ");
        i5.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r5.remove(r5b);
        r5.remove(r5c);
        
        }
     else if(e.getSource()==r6){
            i6.setIcon(new ImageIcon("r6.jpg"));
        r6.setBackground(Color.DARK_GRAY);
        i6.setText(" ");
        i6.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r6.remove(r6b);
        r6.remove(r6c);
        
        }
     else if(e.getSource()==r7){
            i7.setIcon(new ImageIcon("r7.jpg"));
        r7.setBackground(Color.DARK_GRAY);
        i7.setText(" ");
        i7.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r7.remove(r7b);
        r7.remove(r7c);
        
        }
      else if(e.getSource()==r8){
            i8.setIcon(new ImageIcon("r8.jpg"));
        r8.setBackground(Color.DARK_GRAY);
        i8.setText(" ");
        i8.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r8.remove(r8b);
        r8.remove(r8c);
        
        }
     else if(e.getSource()==r9){
            i9.setIcon(new ImageIcon("r9.jpg"));
        r9.setBackground(Color.DARK_GRAY);
        i9.setText(" ");
        i9.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r9.remove(r9b);
        r9.remove(r9c);
        
        }
     else if(e.getSource()==r10){
        i10.setIcon(new ImageIcon("r10.png"));
        r10.setBackground(Color.DARK_GRAY);
        i10.setText(" ");
        i10.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r10.remove(r10b);
        r10.remove(r10c);
        
        }
     else if(e.getSource()==r11){
            i11.setIcon(new ImageIcon("r11.jpg"));
        r11.setBackground(Color.DARK_GRAY);
        i11.setText(" ");
        i11.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r11.remove(r11b);
        r11.remove(r11c);
        
        }
      else if(e.getSource()==r12){
            i12.setIcon(new ImageIcon("r12.jpg"));
        r12.setBackground(Color.DARK_GRAY);
        i12.setText(" ");
        i12.setFont(new java.awt.Font("Forte", Font.ITALIC, 20));
         r12.remove(r12b);
        r12.remove(r12c);
        }
    
    }  
 
    
    public void mouseClicked(MouseEvent e) {
    
    }  
    public void mousePressed(MouseEvent e) {}  
    public void mouseReleased(MouseEvent e) {} 
         
    
}
    
    

